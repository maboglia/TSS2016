/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myShop;

/**
 *
 * @author mauro
 */
public class Utente {
	String username, password, descrizione;
	
	public Utente(String u, String p, String d) {
		username=u;
		password=p;
		descrizione=d;
	}
}
