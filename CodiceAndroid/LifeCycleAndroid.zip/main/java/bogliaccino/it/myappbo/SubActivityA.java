package bogliaccino.it.myappbo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class SubActivityA extends Activity {
    protected final static String TAG = "AppBackStack";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
    }


    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "Sono nel metodo onStart della activity SubActivityA");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "Sono nel metodo onResume della activity SubActivityA");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "Sono nel metodo onRestart della activity SubActivityA");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "Sono nel metodo onPause della activity SubActivityA");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "Sono nel metodo onStop della activity SubActivityA");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Sono nel metodo onDestroy della activity SubActivityA");
    }


    public void sendSMS(View view) {

        Uri uri = Uri.parse("smsto:0800000123");
        Intent it = new Intent(Intent.ACTION_SENDTO, uri);
        it.putExtra("sms_body", "Dicci a DENNNISS che lo voglio bbene");
        startActivity(it);


    }
}
