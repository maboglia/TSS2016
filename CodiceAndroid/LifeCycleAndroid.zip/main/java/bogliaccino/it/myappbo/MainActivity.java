package bogliaccino.it.myappbo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;


public class MainActivity extends Activity {
    protected final static String TAG = "AppBackStack";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d(TAG, "Sono nel metodo onCreate della activity principale");
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "Sono nel metodo onStart della activity principale");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "Sono nel metodo onResume della activity principale");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "Sono nel metodo onRestart della activity principale");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "Sono nel metodo onPause della activity principale");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "Sono nel metodo onStop della activity principale");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Sono nel metodo onDestroy della activity principale");
    }

    public void lanciaActivityA(View view) {

        Intent intento = new Intent(this, SubActivityA.class);
        startActivity(intento);

    }
}
