
public class Bersaglio {

	static int giocate;
	
	private int x, y;

	public Bersaglio(int x, int y) {
		this.x = x;
		this.y = y;
		giocate++;
	}
	
	public int calcolaPunteggio() {
		if (this.x<=1 && this.y<=1){
			return 100;
		}
		else if (this.x<=2 && this.y<=2){
			return 90;
		}
		else if (this.x<=3 && this.y<=3){
			return 80;
		}
		else if (this.x<=4 && this.y<=4){
			return 70;
		}
		else if (this.x<=5 && this.y<=5){
			return 60;
		}
		else if (this.x<=6 && this.y<=6){
			return 50;
		}
		else if (this.x<=7 && this.y<=7){
			return 40;
		}
		else if (this.x<=8 && this.y<=8){
			return 30;
		}
		else if (this.x<=9 && this.y<=9){
			return 20;
		}
		else if (this.x<=10 && this.y<=10){
			return 10;
		}
		
		
		else return 0;	
			
	}
	
	
}
