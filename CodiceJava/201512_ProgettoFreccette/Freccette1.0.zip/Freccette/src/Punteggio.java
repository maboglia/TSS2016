
public class Punteggio {
	
	private int punteggio;

	public Punteggio(int punteggio) {
		this.punteggio = punteggio;
	}

	public int getPunteggio() {
		return this.punteggio;
	}

	public void setPunteggio(int punteggio) {
		this.punteggio += punteggio;
		//System.out.println(this.punteggio);
	}
	
	
	
}
