
public class FreccetteTester {

	public static void main(String[] args) {
		Giocatore player1=new Giocatore("Mauro","Bogliaccino");
		
		System.out.println("Giocatore " + player1.getNome());
		System.out.println("Punteggio iniziale: " + player1.mioPunteggio);

		for (int i = 0; i < 100; i++) {
					player1.lancia();
		System.out.println("Punteggio parziale: " + player1.mioPunteggio);
		
		}
		System.out.println("Punteggio finale player " + player1.getNome() + player1.getCognome());
		System.out.println("------------" + player1.mioPunteggio +"-------------");
		
	}

}
