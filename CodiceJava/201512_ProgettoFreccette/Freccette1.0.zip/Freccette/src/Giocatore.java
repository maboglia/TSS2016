
public class Giocatore {

	private String nome, cognome;
	Punteggio p = new Punteggio(0);
	public int mioPunteggio = p.getPunteggio();
	
	public Giocatore(String nome, String cognome) {
		this.nome = nome;
		this.cognome = cognome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public void lancia() {
		int x = (int) Math.round((Math.random()*10));
		int y = (int) Math.round((Math.random()*10));		
		System.out.print("\t hai colpito x=" + x + " y=" + y +"\t\t");
		Bersaglio b = new Bersaglio(x, y);
		int c = b.calcolaPunteggio();
		//System.out.println(c);
		p.setPunteggio(c);
		mioPunteggio = p.getPunteggio();
	}
	
	
	
}
