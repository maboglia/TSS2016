
/**
 * Classe astratta Clienti - descrivi qui la classe
 * 
 * @author: 
 * Date: 
 */
public abstract class Clienti
{
    // variabili d'istanza - sostituisci l'esempio che segue con il tuo
    private int x;

    /**
     * Un esempio di metodo - aggiungi i tuoi commenti
     * 
     * @param  y    un parametro d'esempio per un metodo
     * @return    la somma di x e y
     */
    public int sampleMethod(int y)
    {
        // metti qui il tuo codice
        return x + y;
    }
}
