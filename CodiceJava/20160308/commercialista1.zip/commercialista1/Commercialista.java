
/**
 * Aggiungi qui una descrizione della classe Commercialista
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
public class Commercialista
{
    // variabili d'istanza - sostituisci l'esempio che segue con il tuo
    private int x;

    /**
     * Costruttore degli oggetti di classe  Commercialista
     */
    public Commercialista()
    {
        // inizializza le variabili d'istanza
        x = 0;
    }

    /**
     * Un esempio di metodo - aggiungi i tuoi commenti
     * 
     * @param  y   un parametro d'esempio per un metodo
     * @return     la somma di x e y
     */
    public int sampleMethod(int y)
    {
        // metti qui il tuo codice
        return x + y;
    }
}
