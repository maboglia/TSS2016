/**
 * Created by mauro on 08/03/16.
 */
public class Libro {

    private String titolo;
    private Abbonato utente;
    private Data scadenza;

    public Libro(String _titolo){
        titolo = _titolo;
        utente = null;
        scadenza = null;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public Abbonato getUtente() {
        return utente;
    }

    public void setUtente(Abbonato utente) {
        this.utente = utente;
    }

    public Data getScadenza() {
        return scadenza;
    }

    public void setScadenza(Data scadenza) {
        this.scadenza = scadenza;
    }
}