/**
 * Created by mauro on 08/03/16.
 */
public class Data {

    private int d, m,y;

    public Data() {
        d=0;
        m=0;
        y=0;
    }

    public int getD() {
        return d;
    }

    public void setD(int d) {
        this.d = d;
    }

    public int getM() {
        return m;
    }

    public void setM(int m) {
        this.m = m;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void nextDay(){
        if(d<30) d++;
        else if (m < 12) {
            d = 1;
            m = 1;
        }
        else {
            d = 1;
            m = 1;
            y++;
        }
    }
    public boolean isEqual(Data date){
        if(date.getD() == d && date.getM() == m && date.getY() == y)
            return true;
        else
            return false;
    }

    public String stampa(){
        return d + "/" + m + "/" + y;
    }

}

