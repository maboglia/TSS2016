import java.util.ArrayList;

/**
 * Created by mauro on 08/03/16.
 */
public class Archivio {

    private ArrayList<Abbonato> utenti;
    private ArrayList<Libro> libri;
    private Data dataCorr;

    public Archivio(Data unaData){
        utenti = new ArrayList<Abbonato>();
        libri = new ArrayList<Libro>();
        dataCorr = unaData;
    }

    public void nuovoLibro(String unTitolo){

        if(trovaLibro(unTitolo) != -1) return;
        Libro nuovoLibro = new Libro(unTitolo);
        libri.add(nuovoLibro);
    }
    public void nuovoUtente(String unNome, String unCognome){

        if(trovaUtente(unNome, unCognome) != -1) return;
        Abbonato nuovoAbbonato = new Abbonato(unNome, unCognome);
        utenti.add(nuovoAbbonato);

    }


    public int trovaUtente(String unNome, String unCognome){

        for (int i = 0; i < utenti.size(); i++) {
            if(
                    utenti.get(i).getNome().equalsIgnoreCase(unNome) &&
                    utenti.get(i).getCognome().equalsIgnoreCase(unCognome)
                    )
                return i;
        }

        return -1;
    }


    public int trovaLibro(String unTitolo){

        for (int i = 0; i < libri.size(); i++) {
            if(libri.get(i).getTitolo().equalsIgnoreCase(unTitolo))
                return i;
        }
        return -1;
    }



    private Data scadenza(Data date){
        Data d = new Data();

        d.setD(date.getD());
        d.setM(date.getM());
        d.setY(date.getY());


        return d;


    }

    /**
     * : si passa in rassegna l’arraylist contenente i libri, se una copia del libro cercato esiste e non è in prestito, viene assegnata una data di scadenza per la restituzione e l’utente che l’ha preso in prestito;
     *
     * */
    public int presta(Libro unLibro, Abbonato unUtente){
        int indexLibro = trovaLibro(unLibro.getTitolo());

        if((indexLibro == -1) || (libri.get(indexLibro).getUtente()) != null)
                return -1;

        int indexUtente=trovaUtente(unUtente.getNome(), unUtente.getCognome());

        if (indexUtente==-1)
            return -1;

        libri.get(indexLibro).setUtente(utenti.get(indexUtente));
        libri.get(indexLibro).setScadenza(this.scadenza(dataCorr));
            return 0;

    }

    /**
     *  - aggiorna():
     *  aggiorna la data, se un libro deve essere restituito nel medesimo giorno, allora si resettano i dati sull’utente possessore.

     */

    public void aggiorna(){
        //dataCorr.nextDay();
        for (Libro l:libri) {
            if(l.getScadenza().isEqual(dataCorr)){
                l.setUtente(null);
                l.setScadenza(null);
            }

        }

    }

        /**- numLibri(Abbonato anAbb): restituisce quanti libri possiede un dato utente*/

    public int numLibri(Abbonato anAbb){

        int nLib = 0;

        for (Libro l:libri) {

            if(
                    l.getUtente().getNome().equalsIgnoreCase(anAbb.getNome()) &&
                    l.getUtente().getCognome().equalsIgnoreCase(anAbb.getCognome())

                    )
                nLib = nLib + 1;

        }

        return nLib;


    }

    public String getDate(){
        return dataCorr.stampa();
    }

    public String getListaLibri(){
        String risposta = "";
        for (Libro l : libri) {
            risposta = risposta + l.getTitolo() + "\n";

        }
        return risposta;

    }

    public String getListaUtenti(){
        String risposta = "";
        for (Abbonato a : utenti) {
            risposta = risposta + a.getNome() + a.getCognome() + "\n";

        }
        return risposta;
    }


}
