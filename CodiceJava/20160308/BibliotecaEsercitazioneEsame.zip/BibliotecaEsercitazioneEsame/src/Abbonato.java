/**
 * Created by mauro on 08/03/16.
 */
public class Abbonato {
    private String cognome, nome;

    public Abbonato(String cognome, String nome) {
        this.cognome = cognome;
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public String getNome() {
        return nome;
    }


}
