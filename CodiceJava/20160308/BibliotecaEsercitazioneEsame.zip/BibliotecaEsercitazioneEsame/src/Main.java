

import java.util.Scanner;

/**
 * Created by mauro on 08/03/16.
 */
public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        Data dataCorrente = new Data();

        dataCorrente.setD(8);
        dataCorrente.setM(3);
        dataCorrente.setY(2016);

        Archivio bibliotecaCivica = new Archivio(dataCorrente);

        boolean stop = false;
        int selezione;

        while(!stop){

            System.out.println("\n");
            System.out.println("Premi: ");
            System.out.println("1) inserisci nuovo libro");
            System.out.println("2) inserisci nuovo utente");
            System.out.println("3) presta libro");
            System.out.println("4) aggiorna archivio");
            System.out.println("5) libri per utente");
            System.out.println("6) elenco libri");
            System.out.println("7) elenco abbonati");
            System.out.println("9) esci");

            selezione = in.nextInt();
            in.nextLine();

            switch (selezione){

                case 1:
                    System.out.println("titolo del libro");
                    String titolo = in.nextLine();
                    bibliotecaCivica.nuovoLibro(titolo);
                    break;
                case 2:
                    System.out.println("scrivi nome");
                    String nome = in.next();
                    System.out.println("scrivi cognome");
                    String cognome = in.next();

                    bibliotecaCivica.nuovoUtente(nome, cognome);

                    break;
                case 3:
                    System.out.println();
                    break;
                case 4:
                    bibliotecaCivica.aggiorna();
                    System.out.println("data aggiornamento" +  bibliotecaCivica.getDate());
                    break;
                case 5:

                    break;
                case 6:
                    System.out.println(bibliotecaCivica.getListaLibri());
                    break;
                case 7:
                    System.out.println(bibliotecaCivica.getListaUtenti());

                    break;
                case 9:
                    stop = true;
                    break;







            }


        }








    }



}
