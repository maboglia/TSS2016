package calcolatore;

import java.util.Scanner;

/**
 * Created by mauro on 22/12/15.
 */
public class Main {


    public static void main(String[] args) {
        double result = 0;

        String s1 = getInput("Inserisci primo valore");
        String s2 = getInput("Inserisci secondo valore");
        String op = getInput("Scegli un'operazione (+ - * /) ");


        try {
            switch (op){

                case "+":
                    result = addizione(s1, s2);
                    break;
                case "-":
                    result = sottrazione(s1, s2);
                    break;
                case "*":
                    result = moltiplicazione(s1, s2);
                    break;
                case "/":
                    result = divisione(s1, s2);
                    break;
                default:
                    System.out.println("Non ho capito cosa devo fare!!! ");
                    break;

            }

            System.out.println("Il risultato del calcolo è: " + result);
        } catch (NumberFormatException e) {
            e.printStackTrace();

            System.out.println("Si è verificato un eroore di calcolo con i parametri che hai inserito, prova ad inserirli nuovamente");
        }


    }

    private static double sottrazione(String s1, String s2) {
        double d1 = Double.parseDouble(s1);
        double d2 = Double.parseDouble(s2);

        return d1-d2;
    }

    private static double addizione(String s1, String s2) {
        double d1 = Double.parseDouble(s1);
        double d2 = Double.parseDouble(s2);

        return d1+d2;
    }
    private static double moltiplicazione(String s1, String s2) {
        double d1 = Double.parseDouble(s1);
        double d2 = Double.parseDouble(s2);

        return d1*d2;
    }

    private static double divisione(String s1, String s2) {
        double d1 = Double.parseDouble(s1);
        double d2 = Double.parseDouble(s2);

        return d1/d2;
    }


    private static String getInput(String s) {
        System.out.println(s);
        Scanner sc = new Scanner(System.in);
        return sc.nextLine();
    }


}
