package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/sample.fxml"));

        /*
        Group root = new Group();
        VBox box = new VBox();
        TextField nameField= new TextField();
        GridPane grid = new GridPane();
        Button btn = new Button();
        Label label = new Label("Nome");
        Text tx = new Text("Made by Mauro");


        tx.setY(100);
        tx.setFont(new Font("Papyrus", 80));
        //root.getChildren().add(tx);
        grid.add(label, 0, 0);
        grid.add(nameField, 1, 0);
        grid.setHgap(20);

        grid.add(btn, 1, 1);

        grid.setGridLinesVisible(true);


        btn.setText("Premi qui");


        btn.setOnAction(event -> System.out.printf("è l'ora dell' %s! %n",nameField.getText() ));
        //root.getChildren().add(btn);
        box.getChildren().addAll(tx, grid);

        root.getChildren().add(box);

        */

        primaryStage.setTitle("Hello TSS 2016");
        primaryStage.setScene(new Scene(root, 300, 275));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
