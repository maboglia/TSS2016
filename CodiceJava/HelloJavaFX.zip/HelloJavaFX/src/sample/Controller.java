package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class Controller {

    @FXML private TextField nome;

    public void faiQualcosa(ActionEvent actionEvent) {

        System.out.printf("funge caro %s! %n", nome.getText());

    }
}
